sudo apt-get install curl -y
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo apt-key fingerprint 0EBFCD88
sudo add-apt-repository    "deb [arch=amd64] https://download.docker.com/linux/ubuntu  $(lsb_release -cs)  stable"
sudo apt-get update -y
sudo apt-get install docker-ce -y
sudo apt-get install openssh-server -y
sudo apt-get install vim -y
sudo apt-get install vlc -y

#sudo apt-get install
sudo curl -L https://github.com/docker/compose/releases/download/1.21.2/docker-compose-$(uname -s)-$(uname -m) -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
docker-compose --version
sudo apt update
sudo docker login --username uvcustomer -p 'Uncanny!2#'
sudo mkdir /uncanny
sudo cp -r ./docker-compose.yml /uncanny/
sudo docker-compose -f /uncanny/docker-compose.yml up -d
sleep 5
sudo wget --load-cookies /tmp/cookies.txt "https://docs.google.com/uc?export=download&confirm=$(wget --quiet --save-cookies /tmp/cookies.txt --keep-session-cookies --no-check-certificate 'https://docs.google.com/uc?export=download&id=1Htd-sCUql2UlhBIgDFEPOGaecg5TODn8' -O- | sed -rn 's/.*confirm=([0-9A-Za-z_]+).*/\1\n/p')&id=1Htd-sCUql2UlhBIgDFEPOGaecg5TODn8" -O LNT_5fps.mp4 && rm -rf /tmp/cookies.txt
sudo cp ./anpr.json /uncanny/anpr/anpr.json
sudo cp ./config_1.json /uncanny/sink/config/config_1.json
sudo cp ./LNT_5fps.mp4 /uncanny
sudo cp ./config.json /uncanny/anpr/instance1/config/config.json
sudo docker restart anpr sink
sleep 20
cd Release_license
wget http://security.ubuntu.com/ubuntu/pool/main/o/openssl1.0/libssl1.0.0_1.0.2n-1ubuntu5.8_amd64.deb
sudo dpkg -i libssl1.0.0_1.0.2n-1ubuntu5.8_amd64.deb
sudo sh run.sh
sudo docker restart anpr
echo "#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@"
echo "#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@"
echo "#@#@#@#@#@#@#@_____Anpr installtion is sucessfully done_____#@#@#@#@##@#@#@#@#"
echo "#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@"
echo "#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@"
cd ..
sudo rm ../neptune.zip
sudo rm -rf ../neptune
